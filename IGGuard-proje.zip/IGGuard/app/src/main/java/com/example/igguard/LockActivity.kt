package com.example.igguard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class LockActivity : Activity() {
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    val q = QUOTES.random()
    val t = TextView(this).apply {
      text = "Bugünlük Instagram süren bitti.\n\n${q.text}\n\n— ${q.source}\n\nYarın 00:00'da yeniden açılır."
      textSize = 19f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(64, 64, 64, 64)
    }
    val btn = Button(this).apply { text = "Tamam"; setOnClickListener { home() } }
    setContentView(LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
      setBackgroundColor(0xFF111111.toInt()); addView(t); addView(btn)
    })
  }
  override fun onBackPressed() = home()
  private fun home() {
    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    finish()
  }
}

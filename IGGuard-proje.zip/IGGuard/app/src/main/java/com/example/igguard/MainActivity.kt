package com.example.igguard

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
  private lateinit var p: Prefs
  private lateinit var usage: TextView
  private lateinit var bar: ProgressBar
  private lateinit var svc: TextView
  private val BG = 0xFF14121F.toInt()
  private val CARD = 0xFF1F1C2E.toInt()
  private val ACC = 0xFF7C5CFF.toInt()
  private val GREY = 0xFFB8B3CC.toInt()

  private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

  private fun tv(t: String, s: Float, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = s; setTextColor(c); if (bold) setTypeface(null, Typeface.BOLD)
  }

  private fun card(vararg v: View) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(18), dp(16), dp(18), dp(16))
    background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(18).toFloat() }
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    v.forEach { addView(it) }
  }

  private fun btn(t: String, f: () -> Unit) = Button(this).apply {
    text = t; isAllCaps = false; setTextColor(Color.WHITE)
    background = GradientDrawable().apply { setColor(ACC); cornerRadius = dp(14).toFloat() }
    layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }
    setOnClickListener { f() }
  }

  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    p = Prefs(this)
    window.statusBarColor = BG
    usage = tv("", 30f, Color.WHITE, true)
    bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
      max = 100; progressTintList = ColorStateList.valueOf(ACC)
    }
    svc = tv("", 15f, Color.WHITE, true)
    val limitTv = tv("", 15f, GREY)
    val seek = SeekBar(this).apply {
      max = 175
      progressTintList = ColorStateList.valueOf(ACC)
      thumbTintList = ColorStateList.valueOf(ACC)
      setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, v: Int, user: Boolean) {
          limitTv.text = "Günlük limit: ${v + 5} dk (artırırsan yarın geçerli)"
          if (user) { p.pending = v + 5; refresh() }
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
      })
      progress = p.pending - 5
    }
    val sw = Switch(this).apply {
      text = "Reels'i engelle"; textSize = 16f; setTextColor(Color.WHITE)
      isChecked = p.blockReels
      setOnCheckedChangeListener { _, c -> p.blockReels = c }
    }
    val quote = tv("", 14f, 0xFFD8D4EA.toInt())
    fun showQuote() { val x = QUOTES.random(); quote.text = "“${x.text}”\n\n— ${x.source}\n\n(değiştirmek için dokun)" }
    quote.setOnClickListener { showQuote() }
    showQuote()

    val root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(20), dp(48), dp(20), dp(28))
      setBackgroundColor(BG)
      addView(tv("IG Koruyucu", 28f, Color.WHITE, true))
      addView(tv("Günlük limit, Reels engeli, gerçek hatırlatmalar.", 14f, GREY))
      addView(card(tv("Bugün", 13f, GREY), usage, bar))
      addView(card(limitTv, seek, sw))
      addView(card(
        svc,
        btn("Erişilebilirlik ayarını aç") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        btn("Pil / otomatik başlat ayarı") {
          startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
      ))
      addView(card(quote))
    }
    setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
  }

  override fun onResume() { super.onResume(); refresh() }

  private fun refresh() {
    p.rollDay()
    val lim = p.limitMin
    usage.text = "${p.usedSec / 60} / $lim dk"
    bar.progress = minOf(100, p.usedSec * 100 / (lim * 60))
    val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
      ?.contains(packageName) == true
    svc.text = if (on) "● Koruma aktif" else "● Koruma kapalı: erişilebilirlik iznini ver"
    svc.setTextColor(if (on) 0xFF4ADE80.toInt() else 0xFFF87171.toInt())
  }
}

package com.example.igguard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
  private lateinit var p: Prefs
  private lateinit var status: TextView

  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    p = Prefs(this)
    val limitTv = TextView(this).apply { textSize = 18f }
    status = TextView(this).apply { textSize = 22f }
    val seek = SeekBar(this).apply {
      max = 175
      setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, v: Int, user: Boolean) {
          limitTv.text = "Günlük limit: ${v + 5} dk (artırırsan yarın geçerli)"
          if (user) { p.pending = v + 5; refresh() }
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
      })
      progress = p.pending - 5
    }
    val sw = Switch(this).apply {
      text = "Reels'i engelle"; isChecked = p.blockReels
      setOnCheckedChangeListener { _, c -> p.blockReels = c }
    }
    val btn = Button(this).apply {
      text = "Erişilebilirlik ayarını aç"
      setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }
    val q = QUOTES.random()
    val quote = TextView(this).apply { text = "${q.text}\n— ${q.source}"; textSize = 15f; setPadding(0, 48, 0, 0) }
    setContentView(ScrollView(this).apply {
      addView(LinearLayout(this@MainActivity).apply {
        orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
        listOf(status, limitTv, seek, sw, btn, quote).forEach { addView(it) }
      })
    })
  }

  override fun onResume() { super.onResume(); refresh() }
  private fun refresh() { p.rollDay(); status.text = "Bugün: ${p.usedSec / 60} / ${p.limitMin} dk" }
}

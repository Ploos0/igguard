package com.example.igguard

import android.content.Context
import java.time.LocalDate

data class Quote(val text: String, val source: String)

val QUOTES = listOf(
  Quote("Pennsylvania Üniversitesi'nde 143 öğrenciyle yapılan çalışmada, Instagram dahil sosyal medyayı günde 30 dakikayla sınırlayanların yalnızlık ve depresyon belirtileri 3 haftada belirgin şekilde azaldı.", "Hunt ve ark., J. of Social and Clinical Psychology, 2018"),
  Quote("Dikkatin bir kez bölündüğünde asıl işine tam dönmen ortalama 23 dakika sürebiliyor.", "Gloria Mark, UC Irvine"),
  Quote("Ekran başında tek bir şeye odaklanma süresi 2004'te ortalama yaklaşık 2,5 dakikaydı; son yıllarda yaklaşık 47 saniye. Dikkatini geri al.", "Gloria Mark, Attention Span (2023)"),
  Quote("Sonsuz kaydırmayı 2006'da tasarlayan Aza Raskin, bu tasarımın insanların inanılmaz miktarda zamanını yuttuğunu söyleyip pişmanlık dile getirdi. Sonsuz akışın dibi yok; durmak sana kalıyor.", "Aza Raskin'in basına verdiği röportajlar"),
  Quote("2010'da Steve Jobs, çocuklarının iPad'i denemediğini, evde teknoloji kullanımını sınırladıklarını söyledi. Ürünü yapanlar bile sınır koyuyor.", "Nick Bilton, New York Times, 2010"),
  Quote("Hayatımız kısa değil; biz onun büyük kısmını harcıyoruz.", "Seneca, Hayatın Kısalığı Üzerine"),
  Quote("1665'te veba yüzünden Cambridge kapandı. Isaac Newton ailesinin çiftliğine döndü ve sonraki aylarda kalkülüs, optik ve yerçekimi fikirlerinin temelini attı. Sessiz, sıkıcı zamanlar bazen en verimli zamanlardır.", "Newton'ın 'mucize yıl' (1665-66) dönemi"),
  Quote("Telefon rehberinden numara kopyalamak gibi sıkıcı bir iş yapanlar, sonraki yaratıcılık testinde daha iyi sonuç aldı. Sıkılmak bozuk bir şey değil.", "Mann ve Cadman, Creativity Research Journal, 2014"),
  Quote("Stanford'da yapılan deneylerde yürüyüş sırasında yaratıcı fikir üretimi ortalama yaklaşık %60 arttı.", "Oppezzo ve Schwartz, 2014"),
  Quote("Yatmadan önce ışık yayan ekrandan okuyanlar daha geç uykuya daldı, melatonin salgıları gecikti ve ertesi sabah daha yorgun uyandı.", "Chang ve ark., PNAS, 2015"),
  Quote("Facebook'u daha çok kullandıkları iki haftalık dönemlerde insanlar anlık ruh hallerini ve yaşam memnuniyetlerini daha düşük bildirdi.", "Kross ve ark., PLOS ONE, 2013"),
  Quote("Reels'te geçirdiğin 30 dakika, ortalama tempoyla yaklaşık 2,5 km yürüyüş demek. Hangisi sana daha çok kalır?", "Basit hesap: yürüyüş hızı ≈ 5 km/sa")
)

class Prefs(c: Context) {
  private val p = c.getSharedPreferences("ig", 0)
  var pending: Int get() = p.getInt("pending", 30); set(v) { p.edit().putInt("pending", v).apply() }
  private var todayLimit: Int get() = p.getInt("today", 30); set(v) { p.edit().putInt("today", v).apply() }
  var usedSec: Int get() = p.getInt("used", 0); set(v) { p.edit().putInt("used", v).apply() }
  var blockReels: Boolean get() = p.getBoolean("reels", true); set(v) { p.edit().putBoolean("reels", v).apply() }
  private var day: String get() = p.getString("day", "") ?: ""; set(v) { p.edit().putString("day", v).apply() }
  // Limit artırmak ertesi gün geçerli; azaltmak hemen geçerli.
  val limitMin get() = minOf(todayLimit, pending)
  val locked get() = usedSec >= limitMin * 60
  fun rollDay() {
    val t = LocalDate.now().toString()
    if (day != t) { day = t; usedSec = 0; todayLimit = pending }
  }
}

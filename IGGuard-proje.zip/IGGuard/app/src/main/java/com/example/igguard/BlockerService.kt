package com.example.igguard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class BlockerService : AccessibilityService() {
  private val h = Handler(Looper.getMainLooper())
  private lateinit var p: Prefs
  private val IG = "com.instagram.android"

  private val tick = object : Runnable {
    override fun run() {
      p.rollDay()
      val root = rootInActiveWindow
      if (root?.packageName == IG) {
        if (p.locked) {
          startActivity(Intent(this@BlockerService, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
          p.usedSec += 1
          if (p.blockReels && inReels(root)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            Toast.makeText(this@BlockerService, QUOTES.random().text, Toast.LENGTH_LONG).show()
          }
        }
      }
      h.postDelayed(this, 1000)
    }
  }

  // Instagram güncellemesiyle ID'ler değişirse yalnızca bu iki satırı güncelle.
  private fun inReels(r: AccessibilityNodeInfo): Boolean {
    val id = "$IG:id/"
    return r.findAccessibilityNodeInfosByViewId(id + "clips_tab").any { it.isSelected } ||
      r.findAccessibilityNodeInfosByViewId(id + "clips_viewer_view_pager").isNotEmpty()
  }

  override fun onServiceConnected() { p = Prefs(this); h.post(tick) }
  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}
  override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }
}
